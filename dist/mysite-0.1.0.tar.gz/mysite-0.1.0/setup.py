# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['mysite']

package_data = \
{'': ['*']}

install_requires = \
['Babel>=2.10.3,<3.0.0',
 'Django>=4.0.6,<5.0.0',
 'dj-database-url>=1.0.0,<2.0.0',
 'gunicorn>=20.1.0,<21.0.0',
 'psycopg2-binary>=2.9.3,<3.0.0',
 'whitenoise[brotli]>=6.2.0,<7.0.0']

setup_kwargs = {
    'name': 'mysite',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'Your Name',
    'author_email': 'you@example.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
